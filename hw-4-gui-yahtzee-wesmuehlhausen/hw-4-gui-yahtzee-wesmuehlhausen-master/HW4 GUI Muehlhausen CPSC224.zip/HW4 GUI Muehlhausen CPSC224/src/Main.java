import javax.swing.*;

/**
 *This class's purpose is to start the entire program
 * CPSC224, Spring 2020
 * No Sources to cite
 * @author Wesley Muehlhausen
 * @version v4.0 3/20/20
 */
public class Main {

    /**
     *RUN PROJECT HERE! This is the main method that fires up the startup GUI
     */
    public static void main(String[] args) {
        JFrame frame = new setupGUI();
        frame.setVisible(true);
    }
}
