import java.util.Random;

/**
    *This class has all of the mechanics for the dice like rolling and getting the roll
    * CPSC224, Spring 2020
    * No Sources to cite
    * @author Wesley Muehlhausen
    * @version v4.0 3/20/20
*/
public class Die {
    private int sides; //each die has a number of sides [numSides]
    private int faceUp; //each die when rolled has a value (faceUp) [value]

    /**
     *This is the constructor method
     * @param sides imports the number of sides on each die
     */
    public Die(int sides) {
        this.sides = sides;
        this.faceUp = 0;
    }

    /**
     *This is the roll method which gives the die a random value based on the number of sides
     * @return value of rolled die
     */
    public int roll(){
        Random random = new Random();
        faceUp = random.nextInt(sides) + 1;
        return faceUp;
    }

    /**
     *This function gives the value of the die
     * @return value of the die is returned
     */
    public int getFaceUp() {
        return faceUp;
    }
}
