

/**
 *This class is pretty straight forward, it takes in the faces of the dice
 * and scores them for each of the possible scoring categories.
 * CPSC224, Spring 2020
 * No Sources to cite
 * @author Wesley Muehlhausen
 * @version v4.0 03/20/20
 */
public class Score {

    private int sides;
    private int rolls;
    private int dice;
    private int[] hand;
    private int upperSubtotal;
    private int upperTotal;
    private int lowerTotal;
    private int grandTotal;
    private int bonus;

    /**
     Constructor for Score class
     */
    public Score(int sides, int rolls, int dice){
        upperSubtotal = 0;
        upperTotal = 0;
        grandTotal = 0;
        lowerTotal = 0;
        bonus = 0;

        this.sides = sides;
        this.rolls = rolls;
        this.dice = dice;
        this.hand = new int[dice];
    }

    /**
     * checks if bonus is greater than 63 and then sets the bonus to 35
     */
    public void updateBonus(){
        if(upperSubtotal >= 63)
            bonus = 35;
    }

    /**
     * Simple getter method for bonus
     * @return bonus value
     */
    public int getBonus(){
        return bonus;
    }

    /**
     *simple get method for the lower bonus
     * @return lower total value
     */
    public int getLowerTotal(){
        return lowerTotal;
    }

    /**
     * adds a value to the lower total value
     * @param value is the value added
     */
    public void addToLowerTotal(int value){
        lowerTotal += value;
    }

    /**
     *adds a value to the total upper value
     * @param value is the value added to upper total value
     */
    public void addToUpperTotal(int value){
        upperTotal += value;
        upperTotal += bonus;
    }

    /**
     *simple getter method for the upper total value
     * @return value of the upper total
     */
    public int getUpperTotal(){
        return upperTotal;
    }

    /**
     *adds value to grand total value
     * @param value adds value to grand total value
     */
    public void addToGrandTotal(int value){
        grandTotal += value;
        grandTotal += bonus;
    }

    /**
     *simple get method for grand total value
     */
    public int getGrandTotal(){
        return grandTotal;
    }

    /**
     *adds value to the value of the upper subtotal
     * @param value is the value being added to upper subtotal
     */
    public void addToUpperSubTotal(int value){
        upperSubtotal += value;
    }

    /**
     *simple get method for the subtotal of the upper scorecard
     */
    public int getUpperSubTotal(){
        return upperSubtotal;
    }

    /**
     * The chance line is the sum of all the single chance lines. I have this as
     return type int instead of void because it is used as the score for some of
     the other methods too.
     * @return num is the score on the chance line
     */
    public int chanceLine(){
        int num = 0;
        for(int i = 0; i < dice; i++){
            num += hand[i];
        }
        return num;
    }

    /**
     * this function calculates and prints the score for each chance slot not to
     be confused with the total chance column.
     * @param pos determines which individual chance line to score
     *@return the score of the function
     */
    public int individualChanceValue(int pos) {
        int[] scorecard = new int[sides];
        for(int die = 0; die < dice; die++){//for every die
            for(int side = 1; side <= sides; side++){//check if each side matches with the current face
                if(hand[die] == side)
                    scorecard[side-1] += side;
            }
        }
        return scorecard[pos];
    }

    /**
     *This method finds three of a kind by looping through and checking if
     an element has the same value as both the elements before and after
     and also prints out the score
     * @return the score of the function
     */
    public int threeOfK(){
        boolean triple = false;
        for(int i = 1; i < dice-1; i++){
            if(hand[i] == hand[i-1] && hand[i] == hand[i+1]){
                triple = true;
            }
        }
        if(triple == true)
            return chanceLine();
        else
            return 0;
    }

    /**
     *This method takes the logic from 3OK and checks one more element on top
     of that which then prints the result
     *@return the score of the function
     */
    public int fourOfK(){
        boolean quad = false;
        for(int i = 1; i < dice - 2; i++){
            if(hand[i] == hand[i-1] && hand[i] == hand[i+1])
                if(hand[i] == hand[i+2]){
                    quad = true;
                }
        }
        if(quad == true)
            return chanceLine();
        else
            return 0;
    }

    /**
     * fullHouse first finds three of a kind, and then if that is true, it then
     loops through again to find a pair of which is not the same value as the
     set of three. Then prints it.
     *@return the score of the function
     */
    public int fullHouse() {
        boolean triples = false;
        boolean doubles = false;
        if (dice >= 5) {
            int key = -1;
            //checks for a three of a kind
            for (int i = 1; i < dice - 1; i++) {
                if (hand[i] == hand[i-1] && hand[i] == hand[i+1]) {
                    triples = true;
                    key = hand[i];
                }
            }
            if (triples == true) {//if there is a set of three...
                for (int i = 0; i < dice - 1; i++) {
                    if(hand[i] == hand[i+1] && hand[i] != key) {
                        doubles = true;
                    }
                }
            }
        }
        if(doubles == true)
            return 25;
        else
            return 0;
    }

    /**
     * checks for small straight by looping through and seeing if the following
     element is one larger than the current element.
     *@return the score of the function
     */
    public int smallStr(){
        int num = 0;
        for(int i = 0; i < hand.length-1; i++){
            if(hand[i] == hand[i+1]-1){
                num++;
            }
        }
        if(num >= 3){
            return 30;
        }
        else
            return 0;
    }

    /**
     * Same as the small straight method but has to be 5 in a row instead of 4
     *@return the score of the function
     */
    public int largeStr(){
        int num = 0;
        for(int i = 0; i < hand.length-1; i++){
            if(hand[i] == hand[i+1]-1){
                num++;
            }
        }
        if(num >= 4){
            return 40;
        }
        else
            return 0;
    }
    /**
     *checks for yahtzee which is all the same. if one is not the same as another
     if will give a score of 0. This is not made for just 5 in a row, they all have
     to be the same
     *@return the score of the function
     */
    public int yahtzee(){
        boolean allSame = true;
        for(int i = 0; i < dice; i++){
            if(hand[i] != hand[0])
                allSame = false;
        }
        if(allSame == true)
            return 50;
        else
            return 0;
    }

    /**
     *simple getter method for getting a dice value of a certain die
     * @param index is the position of the die in hand
     * @param value is the value of that die
     */
    public void getDieValue(int index, int value){
        hand[index] = value;
    }

}
