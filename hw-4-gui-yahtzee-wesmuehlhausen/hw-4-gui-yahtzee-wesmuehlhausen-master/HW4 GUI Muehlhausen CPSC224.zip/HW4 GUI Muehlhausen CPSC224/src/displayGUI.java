import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *This is the main GUI of the entire program which runs the game of yahtzee
 * CPSC224, Spring 2020
 * No Sources to cite
 * @author Wesley Muehlhausen
 * @version v4.0 3/20/20
 */
public class displayGUI extends JFrame{

    /**
     *all of the components of the GUI
     */
    private JButton button1;
    private JButton button2;
    private JButton button3;
    private JButton button4;
    private JButton button5;
    private JButton[] rollDice;
    private JButton[] indivChance;
    private boolean[] keepDice;
    private JButton rollButton;
    private JPanel mainPanel;
    private JButton button6;
    private JButton button7;
    private JButton scoreButton;
    private JButton chanceLineScore;
    private JButton chanceScore1;
    private JButton chanceScore2;
    private JButton chanceScore3;
    private JButton chanceScore4;
    private JButton chanceScore5;
    private JButton chanceScore6;
    private JButton chanceScore7;
    private JButton chanceScore8;
    private JButton chanceScore9;
    private JButton chanceScore10;
    private JButton chanceScore11;
    private JButton chanceScore12;
    private JButton TOKButton;
    private JButton FOKButton;
    private JButton fullHouseButton;
    private JButton smallStraightButton;
    private JButton largeStraightButton;
    private JButton yahtzeeButton;
    private JLabel upperBonus;
    private JLabel upperTotal;
    private JLabel upperScoreCardSubTotal;
    private JLabel lowerTotal;
    private JLabel grandTotal;
    private JButton endGame;

    public final int NUMBER_OF_DICE;
    public final int NUMBER_OF_SIDES;
    public final int MAX_NUMBER_OF_ROLLS;
    private int turn;
    private int curRolls;
    private Hand hand;
    private Score score;


    /**
     *Constructor for the class which includes all of the action buttons
     */
    public displayGUI(int dice, int sides, int rolls) {
        NUMBER_OF_DICE = dice;
        NUMBER_OF_SIDES = sides;
        MAX_NUMBER_OF_ROLLS = rolls;
        setupParams();
        setupConfigs();

        /**
         *This is the action event button code for the roll button. This rolls each of the
         * dice and sets the image to the corresponding number on click
         */
        rollButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                    for(int i = 0; i < NUMBER_OF_DICE; i++){
                        if(!keepDice[i]) {hand.rollOneDie(i);}
                        setImage(i, (hand.getDiceValue(i)-1));
                    }
                    curRolls++;
                    if(curRolls >= MAX_NUMBER_OF_ROLLS){rollButton.setEnabled(false);}
                    scoreButton.setEnabled(true);
                    canClickDice(true);
                }
        });

        /**
         *This is the action event button code for the score button. Once the dice have been
         * rolled they can be scored which sorts the dice and calculates all of the possible
         * score options
         */
        scoreButton.addActionListener(new ActionListener() {
            @Override
                public void actionPerformed(ActionEvent e) {
                    curRolls = 0;
                    hand.sortDice();
                    for(int i = 0; i < keepDice.length; i++){
                        keepDice[i] = false;
                        setImage(i, (hand.getDiceValue(i)-1));
                        rollDice[i].setBackground(Color.GREEN);
                    }
                    for(int i = 0; i < NUMBER_OF_DICE; i++){
                        score.getDieValue(i, hand.getDiceValue(i));
                    }
                    chanceLineScore.setText("Chance: " + score.chanceLine());
                    TOKButton.setText("Three of Kind: " + score.threeOfK());
                    FOKButton.setText("Four of Kind: " + score.fourOfK());
                    fullHouseButton.setText("Full House: " + score.fullHouse());
                    smallStraightButton.setText("Small Straight: " + score.smallStr());
                    largeStraightButton.setText("Large Straight: " + score.largeStr());
                    yahtzeeButton.setText("Yahtzee: " + score.yahtzee());
                    for(int i = 0; i < NUMBER_OF_SIDES; i++)
                        indivChance[i].setText((i + 1) + "'s Line: " + score.individualChanceValue(i));
                    upperScoreCardSubTotal.setText("Upper Subtotal: " + score.getUpperSubTotal());

                    rollButton.setEnabled(false);
                    scoreButton.setEnabled(false);
                    canScore(true);
                    if(turn == NUMBER_OF_SIDES + 7){endGame.setVisible(true);}
            }

        });

        /**
         *This is the action event button code for the die #1
         * When the button is clicked it toggles from unclickable to clickable
         */
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                toggle(0);
            }
        });

        /**
         *This is the action event button code for the die #2
         * When the button is clicked it toggles from unclickable to clickable
         */
        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                toggle(1);
            }
        });

        /**
         *This is the action event button code for the die #3
         * When the button is clicked it toggles from unclickable to clickable
         */
        button3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                toggle(2);
            }
        });

        /**
         *This is the action event button code for the die #4
         * When the button is clicked it toggles from unclickable to clickable
         */
        button4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                toggle(3);
            }
        });

        /**
         *This is the action event button code for the die #5
         * When the button is clicked it toggles from unclickable to clickable
         */
        button5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                toggle(4);
            }
        });

        /**
         *This is the action event button code for the die #6
         * When the button is clicked it toggles from unclickable to clickable
         */
        button6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                toggle(5);
            }
        });

        /**
         *This is the action event button code for the die #7
         * When the button is clicked it toggles from unclickable to clickable
         */
        button7.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                toggle(6);
            }
        });

        /**
         *This is the action event button code for chance button 1
         * When the button is clicked it dissapears and scores itself on the scoreboard
         */
        chanceScore1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateScoring(0);
                chanceScore1.setVisible(false);
            }
        });

        /**
         *This is the action event button code for chance button 2
         * When the button is clicked it disappears and scores itself on the scoreboard
         */
        chanceScore2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateScoring(1);
                chanceScore2.setVisible(false);
            }
        });

        /**
         *This is the action event button code for chance button 3
         * When the button is clicked it disappears and scores itself on the scoreboard
         */
        chanceScore3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateScoring(2);
                chanceScore3.setVisible(false);
            }
        });

        /**
         *This is the action event button code for chance button 4
         * When the button is clicked it disappears and scores itself on the scoreboard
         */
        chanceScore4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateScoring(3);
                chanceScore4.setVisible(false);
            }
        });

        /**
         *This is the action event button code for chance button 5
         * When the button is clicked it disappears and scores itself on the scoreboard
         */
        chanceScore5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateScoring(4);
                chanceScore5.setVisible(false);
            }
        });

        /**
         *This is the action event button code for chance button 6
         * When the button is clicked it disappears and scores itself on the scoreboard
         */
        chanceScore6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateScoring(5);
                chanceScore6.setVisible(false);
            }
        });

        /**
         *This is the action event button code for chance button 7
         * When the button is clicked it disappears and scores itself on the scoreboard
         */
        chanceScore7.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateScoring(6);
                chanceScore7.setVisible(false);
            }
        });

        /**
         *This is the action event button code for chance button 8
         * When the button is clicked it disappears and scores itself on the scoreboard
         */
        chanceScore8.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateScoring(7);
                chanceScore8.setVisible(false);
            }
        });

        /**
         *This is the action event button code for chance button 9
         * When the button is clicked it disappears and scores itself on the scoreboard
         */
        chanceScore9.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateScoring(8);
                chanceScore9.setVisible(false);
            }
        });

        /**
         *This is the action event button code for chance button 10
         * When the button is clicked it disappears and scores itself on the scoreboard
         */
        chanceScore10.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateScoring(9);
                chanceScore10.setVisible(false);
            }
        });

        /**
         *This is the action event button code for chance button 11
         * When the button is clicked it disappears and scores itself on the scoreboard
         */
        chanceScore11.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateScoring(10);
                chanceScore11.setVisible(false);
            }
        });

        /**
         *This is the action event button code for chance button 12
         * When the button is clicked it disappears and scores itself on the scoreboard
         */
        chanceScore12.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateScoring(11);
                chanceScore12.setVisible(false);
            }
        });

        /**
         *This is the action event button code for the chance line button
         * When the button is clicked it disappears and scores itself on the scoreboard
         */
        chanceLineScore.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateLowerScoring(score.chanceLine());
                chanceLineScore.setVisible(false);
            }
        });

        /**
         *This is the action event button code for the three of kind button
         * When the button is clicked it disappears and scores itself on the scoreboard
         */
        TOKButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateLowerScoring(score.threeOfK());
                TOKButton.setVisible(false);
            }
        });

        /**
         *This is the action event button code for the four of kind button
         * When the button is clicked it disappears and scores itself on the scoreboard
         */
        FOKButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateLowerScoring(score.fourOfK());
                FOKButton.setVisible(false);
            }
        });

        /**
         *This is the action event button code for the small straight button
         * When the button is clicked it disappears and scores itself on the scoreboard
         */
        smallStraightButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateLowerScoring(score.smallStr());
                smallStraightButton.setVisible(false);

            }
        });

        /**
         *This is the action event button code for the large straight button
         * When the button is clicked it disappears and scores itself on the scoreboard
         */
        largeStraightButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateLowerScoring(score.largeStr());
                largeStraightButton.setVisible(false);

            }
        });

        /**
         *This is the action event button code for chance button
         * When the button is clicked it disappears and scores itself on the scoreboard
         */
        fullHouseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateLowerScoring(score.fullHouse());
                fullHouseButton.setVisible(false);
            }
        });

        /**
         *This is the action event button code for the yahtzee button
         * When the button is clicked it disappears and scores itself on the scoreboard
         */
        yahtzeeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateLowerScoring(score.yahtzee());
                yahtzeeButton.setVisible(false);
            }
        });

        /**
         *This is the action event button code for the END GAME button
         * When the game is over this button appears and when the button
         * is clicked it disappears
         */
        endGame.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame endscreen = new endGUI(score.getGrandTotal());
                endscreen.setVisible(true);
                endscreen.setSize(500, 300);
                dispose();
            }
        });
    }

    /**
     *This method updates all of the score categories including upper and lower scorecard
     */
    public void updateScoring(int index){
        score.addToUpperSubTotal(score.individualChanceValue(index));
        score.updateBonus();
        score.addToUpperTotal(score.individualChanceValue(index));
        score.addToGrandTotal(score.individualChanceValue(index));

        upperBonus.setText("Upper Bonus: " + score.getBonus());
        upperScoreCardSubTotal.setText("Upper Subtotal: " + score.getUpperSubTotal());
        upperTotal.setText("Upper Total: " + score.getUpperTotal());
        grandTotal.setText("Grand Total: " + score.getGrandTotal());

        rollButton.setEnabled(true);
        canScore(false);
        turn++;
        checkEndGame();
    }

    /**
     *This method updates the lower scorecard
     * @param value is the value added to lower scorecard
     */
    public void updateLowerScoring(int value){
        score.addToLowerTotal(value);
        score.addToGrandTotal(value);
        lowerTotal.setText("Lower Total: " + score.getLowerTotal());
        grandTotal.setText("Grand Total: " + score.getGrandTotal());

        rollButton.setEnabled(true);
        canScore(false);
        turn++;
        checkEndGame();
    }

    /**
     *This method toggles the dice from red to green which means
     * the dice will either roll or not reroll
     * @param index is the specific die to be updated
     */
    public void toggle(int index){
        if(rollDice[index].getBackground() == Color.GREEN){rollDice[index].setBackground(Color.RED);}
        else if(rollDice[index].getBackground() == Color.RED){rollDice[index].setBackground(Color.GREEN);}
        keepDice[index] = !keepDice[index];//Toggles the button's value
    }

    /**
     *This method controls whether the buttons of the scorecard can be pressed or not
     * @param canSelectScore is whether they can be scored or not
     */
    public void canScore(boolean canSelectScore){
        chanceScore1.setEnabled(canSelectScore);
        chanceScore2.setEnabled(canSelectScore);
        chanceScore3.setEnabled(canSelectScore);
        chanceScore4.setEnabled(canSelectScore);
        chanceScore5.setEnabled(canSelectScore);
        chanceScore6.setEnabled(canSelectScore);
        if(NUMBER_OF_SIDES >= 7){
            chanceScore7.setEnabled(canSelectScore);
            chanceScore8.setEnabled(canSelectScore);
        }
        if(NUMBER_OF_SIDES >= 9) {
            chanceScore9.setEnabled(canSelectScore);
            chanceScore10.setEnabled(canSelectScore);
            chanceScore11.setEnabled(canSelectScore);
            chanceScore12.setEnabled(canSelectScore);
        }
        chanceLineScore.setEnabled(canSelectScore);
        TOKButton.setEnabled(canSelectScore);
        FOKButton.setEnabled(canSelectScore);
        fullHouseButton.setEnabled(canSelectScore);
        smallStraightButton.setEnabled(canSelectScore);
        largeStraightButton.setEnabled(canSelectScore);
        yahtzeeButton.setEnabled(canSelectScore);
    }

    /**
     *This method controls whether the dice at the top of the screen can
     * be toggled
     * @param canClick controls the toggle
     */
    public void canClickDice(boolean canClick){
        for(int i = 0; i < keepDice.length; i++){
            rollDice[i].setEnabled(canClick);
        }
    }

    /**
     *This method checks if its time to reveal the end game button
     */
    public void checkEndGame(){
        if(turn == NUMBER_OF_SIDES + 7){
            endGame.setVisible(true);
            rollButton.setEnabled(false);
        }
    }

    /**
     *This method sets the image on the dice buttons
     * @param buttonPos is which die is being updated
     * @param value is which die value it gets
     */
    public void setImage(int buttonPos, int value){
        if(value == 0)
            rollDice[buttonPos].setIcon(new ImageIcon("src\\imagesFolder\\die1.png"));
        else if(value == 1)
            rollDice[buttonPos].setIcon(new ImageIcon("src\\imagesFolder\\die2.png"));
        else if(value == 2)
            rollDice[buttonPos].setIcon(new ImageIcon("src\\imagesFolder\\die3.png"));
        else if(value == 3)
            rollDice[buttonPos].setIcon(new ImageIcon("src\\imagesFolder\\die4.png"));
        else if(value == 4)
            rollDice[buttonPos].setIcon(new ImageIcon("src\\imagesFolder\\die5.png"));
        else if(value == 5)
            rollDice[buttonPos].setIcon(new ImageIcon("src\\imagesFolder\\die6.png"));
        else if(value == 6)
            rollDice[buttonPos].setIcon(new ImageIcon("src\\imagesFolder\\die7.png"));
        else if(value == 7)
            rollDice[buttonPos].setIcon(new ImageIcon("src\\imagesFolder\\die8.png"));
        else if(value == 8)
            rollDice[buttonPos].setIcon(new ImageIcon("src\\imagesFolder\\die9.png"));
        else if(value == 9)
            rollDice[buttonPos].setIcon(new ImageIcon("src\\imagesFolder\\die10.png"));
        else if(value == 10)
            rollDice[buttonPos].setIcon(new ImageIcon("src\\imagesFolder\\die11.png"));
        else
            rollDice[buttonPos].setIcon(new ImageIcon("src\\imagesFolder\\die12.png"));
    }

    /**
     *This method sets up general configurations at the start of the class
     */
    public void setupConfigs(){
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setContentPane(mainPanel);
        this.pack();
        rollButton.setFocusPainted(false);
        scoreButton.setFocusPainted(false);
        canClickDice(false);
        scoreButton.setEnabled(false);
        canScore(false);
        endGame.setVisible(false);
    }
    /**
     *This method sets up general parameters at the start of the class
     */
    public void setupParams(){
        turn = 0;
        score = new Score(NUMBER_OF_SIDES, MAX_NUMBER_OF_ROLLS, NUMBER_OF_DICE);
        hand = new Hand(NUMBER_OF_DICE, NUMBER_OF_SIDES);
        rollDice = new JButton[NUMBER_OF_DICE];
        rollDice[0] = button1;
        rollDice[1] = button2;
        rollDice[2] = button3;
        rollDice[3] = button4;
        rollDice[4] = button5;
        if(NUMBER_OF_DICE >= 6){rollDice[5] = button6;}
        else{button6.setVisible(false);}
        if(NUMBER_OF_DICE == 7){rollDice[6] = button7;}
        else{button7.setVisible(false);}

        indivChance = new JButton[NUMBER_OF_SIDES];
        indivChance[0] = chanceScore1;
        indivChance[1] = chanceScore2;
        indivChance[2] = chanceScore3;
        indivChance[3] = chanceScore4;
        indivChance[4] = chanceScore5;
        indivChance[5] = chanceScore6;
        if(NUMBER_OF_SIDES >= 7)
            indivChance[6] = chanceScore7;
        else{chanceScore7.setVisible(false);}
        if(NUMBER_OF_SIDES >= 8)
            indivChance[7] = chanceScore8;
        else{chanceScore8.setVisible(false);}
        if(NUMBER_OF_SIDES >= 9)
            indivChance[8] = chanceScore9;
        else{chanceScore9.setVisible(false);}
        if(NUMBER_OF_SIDES >= 10)
            indivChance[9] = chanceScore10;
        else{chanceScore10.setVisible(false);}
        if(NUMBER_OF_SIDES >= 11)
            indivChance[10] = chanceScore11;
        else{chanceScore11.setVisible(false);}
        if(NUMBER_OF_SIDES >= 12)
            indivChance[11] = chanceScore12;
        else{chanceScore12.setVisible(false);}
        keepDice = new boolean[NUMBER_OF_DICE];
        curRolls = 0;
        for(int i = 0; i < NUMBER_OF_DICE; i++){
            rollDice[i].setBackground(Color.GREEN);
            rollDice[i].setFocusPainted(false);
        }

    }

    }



