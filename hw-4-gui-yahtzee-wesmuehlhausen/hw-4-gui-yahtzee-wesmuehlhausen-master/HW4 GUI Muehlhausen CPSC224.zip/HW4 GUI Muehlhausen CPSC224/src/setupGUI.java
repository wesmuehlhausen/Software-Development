import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *This class controlls the GUI for the startup panel
 * CPSC224, Spring 2020
 * No Sources to cite
 * @author Wesley Muehlhausen
 * @version v4.0 03/20/20
 */
public class setupGUI extends JFrame{
    private JPanel mainPanel;
    private JComboBox sidesSelector;
    private JComboBox diceSelector;
    private JTextField rollsSelector;
    private JButton startButton;

    /**
     *This is the constructor for the GUI. This adds all of the general
     * settings and layout instructions for the GUI
     */
    public setupGUI(){
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.setContentPane(mainPanel);
        this.pack();
        sidesSelector.addItem(6);
        sidesSelector.addItem(8);
        sidesSelector.addItem(12);
        diceSelector.addItem(5);
        diceSelector.addItem(6);
        diceSelector.addItem(7);
        startButton.setFocusPainted(false);

        /**
         * This button when clicked closes this GUI and invokes the setup class
         */
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(checkInput()){
                Setup setup = new Setup((int)diceSelector.getSelectedItem(), (int)sidesSelector.getSelectedItem(), Integer.parseInt(rollsSelector.getText()));
                dispose();}
            }
        });
    }

    /**
     * This method checks to see if the input is actually a number
     */
    public boolean checkInput(){
        String input = "";
        try {
            int x = Integer.parseInt(rollsSelector.getText());
            System.out.println("Valid input");
            return true;
        }catch(NumberFormatException e) {
            System.out.println("input is not an int value");
            return false;
        }
    }


}
