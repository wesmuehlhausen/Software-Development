import javax.swing.*;

/**
 *This class's purpose is to setup the parameters of the display GUI
 * CPSC224, Spring 2020
 * No Sources to cite
 * @author Wesley Muehlhausen
 * @version v4.0 3/20/20
 */
public class Setup {
    public Setup(int dice, int sides, int rolls) {
        JFrame frame = new displayGUI(dice, sides, rolls);
        frame.setVisible(true);
        frame.setSize(500, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();

    }
}
