/**
 *This class creates and holds a hand which can roll dice and sort the hand.
 * CPSC224, Spring 2020
 * No Sources to cite
 * @author Wesley Muehlhausen
 * @version v4.0 3/20/20
 */

public class Hand {
    private int dice; //[numDice]
    private int sides;//[numSides]
    private Die [] diceHand; //[rollArray]

    /**
     * Constructor for hand default values based on the parameters.
     * @param sides on dice
     * @param dice in game
     */
    public Hand(int dice, int sides){
        this.dice = dice;
        this.sides = sides;
        this.diceHand = new Die[dice];
        for(int i = 0; i < dice; i++)
            diceHand[i] = new Die(sides);
    }

    /**
     * gives a dice value of a certain die in the hand based on its position
     * @param index
     * @return the roll of that die
     */
    public int getDiceValue(int index){
        return diceHand[index].getFaceUp();
    }

    /**
     * rolls a specific die in hand based on index
     * @param index is the position in the hand
     * @return value of that die rolled
     */
    public int rollOneDie(int index){
        return diceHand[index].roll();
    }

    /**
     *Does a bubble sort on the hand
     */
    public void sortDice(){
        //Uses basic bubble sorting technique to sort hand
        boolean swapped = true;
        int limit = 0;
        Die tmp;
        while (swapped) {
            swapped = false;
            limit++;
            for (int i = 0; i < dice - limit; i++) {
                if (diceHand[i].getFaceUp() > diceHand[i+1].getFaceUp()) {
                    tmp = diceHand[i];
                    diceHand[i] = diceHand[i+1];
                    diceHand[i+1] = tmp;
                    swapped = true;
                }
            }
        }
    }
}
