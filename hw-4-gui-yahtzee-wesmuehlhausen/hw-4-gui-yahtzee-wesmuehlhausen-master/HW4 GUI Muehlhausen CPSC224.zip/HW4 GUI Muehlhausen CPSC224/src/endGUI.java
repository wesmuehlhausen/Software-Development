import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *This class controlls the GUI for the end game panel. Where you can either restart or quit
 * CPSC224, Spring 2020
 * No Sources to cite
 * @author Wesley Muehlhausen
 * @version v4.0 03/20/20
 */
public class endGUI extends JFrame {
    private JButton playAgainButton;
    private JButton endGameButton;
    private JLabel titleLabel;
    private JPanel mainPanel;

    /**
     * This is the constructor for the GUI
     * This sets up all of the general settings for it
     * @param score is the final score for the game
     */
    public endGUI(int score){
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.setContentPane(mainPanel);
        this.pack();
        titleLabel.setText("Congratulations your score was: " + score);

        /**
         *This button when pressed closes this GUI
         */
        endGameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        /**
         *This button when pressed starts up another game
         */
        playAgainButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                JFrame frame = new setupGUI();
                frame.setVisible(true);
                frame.setSize(500, 300);
            }
        });
    }
}
